#ifndef TP_AVAIL_H
#define TP_AVAIL_H

/* function prototypes from avail.c */

void *tp_alloc(size_t n);

int total_mem(void);

#endif  /* ! TP_AVAIL_H */
