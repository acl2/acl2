#ifndef TP_HEADER_H
#define TP_HEADER_H

/************ BASIC INCLUDES ************/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

/******** Types of exit ********/

#define ABEND_EXIT           11
#define UNSATISFIABLE_EXIT   12
#define MAX_SECONDS_EXIT     13
#define MAX_MEM_EXIT         14
#define MAX_MODELS_EXIT      15
#define ALL_MODELS_EXIT      16

/************* END OF ALL GLOBAL CONSTANT DEFINITIONS ****************/

#include "Options.h"
#include "Stats.h"
#include "Avail.h"
#include "Clocks.h"
#include "Misc.h"

/***********************************************************************/

#endif  /* ! TP_HEADER_H */
