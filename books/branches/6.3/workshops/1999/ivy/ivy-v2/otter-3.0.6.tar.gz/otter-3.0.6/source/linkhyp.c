/*
 *  linkhyp.c -- linked hyperresolution
 *
 */

#include "header.h"

/*************
 *
 *    linked_hyper_res(giv_cl)
 *
 *************/

void linked_hyper_res(giv_cl)
     struct clause *giv_cl;
{
    printf("linked hyper not implemented yet.\n");
}  /* linked_hyper_res */

