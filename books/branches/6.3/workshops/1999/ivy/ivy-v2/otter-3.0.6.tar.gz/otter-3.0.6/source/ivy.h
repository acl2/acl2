struct list *init_proof_object(FILE *fin, FILE *fout);
struct proof_object *retrieve_initial_proof_object(void);

