/* proto.h made 
Tue Feb 17 15:08:59 CST 1998
*/

/* main.c */

void print_banner();

/* av.c */

int **tp_alloc();
struct term *get_term();
void free_term();
struct rel *get_rel();
void free_rel();
struct sym_ent *get_sym_ent();
void free_sym_ent();
struct term_ptr *get_term_ptr();
void free_term_ptr();
struct formula_ptr_2 *get_formula_ptr_2();
void free_formula_ptr_2();
struct fpa_tree *get_fpa_tree();
void free_fpa_tree();
struct fpa_head *get_fpa_head();
void free_fpa_head();
struct context *get_context();
void free_context();
struct trail *get_trail();
void free_trail();
struct imd_tree *get_imd_tree();
void free_imd_tree();
struct imd_pos *get_imd_pos();
void free_imd_pos();
struct is_tree *get_is_tree();
void free_is_tree();
struct is_pos *get_is_pos();
void free_is_pos();
struct fsub_pos *get_fsub_pos();
void free_fsub_pos();
struct literal *get_literal();
void free_literal();
struct clause *get_clause();
void free_clause();
struct list *get_list();
void free_list();
struct clash_nd *get_clash_nd();
void free_clash_nd();
struct clause_ptr *get_clause_ptr();
void free_clause_ptr();
struct int_ptr *get_int_ptr();
void free_int_ptr();
struct ans_lit_node *get_ans_lit_node();
void free_ans_lit_node();
struct formula_box *get_formula_box();
void free_formula_box();
struct formula *get_formula();
void free_formula();
struct formula_ptr *get_formula_ptr();
void free_formula_ptr();
struct cl_attribute *get_cl_attribute();
void free_cl_attribute();
struct link_node *get_link_node();
void free_link_node();
void free_imd_pos_list();
void free_is_pos_list();
void print_mem();
void print_mem_brief();
int total_mem();
int total_mem_calls();
void print_linked_ur_mem_stats();

/* io.c */

int str_double();
void double_str();
int str_int();
void int_str();
int str_long();
int bits_ulong();
void long_str();
void ulong_bits();
void cat_str();
int str_ident();
void reverse();
struct sym_ent *insert_sym();
int str_to_sn();
void print_syms();
void p_syms();
char *sn_to_str();
int sn_to_arity();
struct sym_ent *sn_to_node();
int sn_to_ec();
struct sym_ent *sym_tab_member();
int in_sym_tab();
void free_sym_tab();
int is_symbol();
void mark_as_skolem();
int is_skolem();
int initial_str();
int set_vars();
int set_vars_term();
int var_name();
struct term_ptr *read_list();
void print_list();
void bird_print();
void write_term();
void display_term();
void print_term();
void p_term();
void d_term();
void print_term_nl();
int print_term_length();
void  pretty_print_term();
void print_variable();
void built_in_symbols();
int declare_op();
void init_special_ops();
int process_op_command();
void skip_white();
int name_sym();
void print_error();
struct term *seq_to_term();
struct term *str_to_term();
int read_buf();
struct term *term_fixup();
struct term *term_fixup_2();
struct term *read_term();
void merge_sort();
int compare_for_auto_lex_order();
void auto_lex_order();

/* share.c */

struct term *integrate_term();
void disintegrate_term();
void set_up_pointers();
void zap_term();
void print_term_tab();
void p_term_tab();
void test_terms();
struct term_ptr *all_instances();
struct term_ptr *all_instances_fpa();
void bd_kludge_insert();
void bd_kludge_delete();

/* fpa.c */

struct fpa_index *alloc_fpa_index();
void term_fpa_rec();
void fpa_insert();
void fpa_delete();
struct fpa_tree *build_tree();
struct term *next_term();
struct fpa_tree *build_for_all();
void zap_prop_tree();
void print_fpa_tab();
void p_fpa_tab();
void print_prop_tree();
void p_prop_tree();
void print_path();
void p_path();
int new_sym_num();

/* clocks.c */

void clock_init();
long clock_val();
void clock_reset();
char *get_time();
long system_time();
long run_time();
long wall_seconds();

/* unify.c */

int occur_check();
int unify();
int unify_no_occur_check();
int match();
struct term *apply();
int term_ident();
void clear_subst_2();
void clear_subst_1();
void print_subst();
void p_subst();
void print_trail();

/* demod.c */

struct term *convenient_demod();
void zap_term_special();
struct term *apply_demod();
void demod_cl();
void back_demod();
int lit_t_f_reduce();
int check_input_demod();
int dynamic_demodulator();
struct clause *new_demod();

/* weight.c */

struct term_ptr *read_wt_list();
int noncomplexifying();
int overbeek_match();
int weight();
int wt_match();
void set_wt_list();
void weight_index_delete();
int lex_order();
int lex_order_vars();
int lex_check();
int var_subset();
void order_equalities();
int term_ident_x_vars();

/* imd.c */

void imd_insert();
void imd_delete();
struct term *contract_imd();
void print_imd_tree();
void p_imd_tree();

/* is.c */

void is_insert();
void is_delete();
struct term_ptr *is_retrieve();
struct term *fs_retrieve();
void canc_fs_pos();
void print_is_tree();
void p_is_tree();

/* clause.c */

void reset_clause_counter();
int next_cl_num();
void assign_cl_id();
void hot_cl_integrate();
void cl_integrate();
void cl_del_int();
void cl_del_non();
void cl_int_chk();
struct term *clause_to_term();
struct clause *term_to_clause();
struct clause *read_sequent_clause();
struct clause *read_clause();
struct list *read_cl_list();
int set_vars_cl();
void print_sequent_clause();
void print_clause();
void p_clause();
void print_cl_list();
void cl_merge();
int tautology();
int prf_weight();
int proof_length();
int subsume();
int map_rest();
int anc_subsume();
struct clause *for_sub_prop();
struct clause *forward_subsume();
struct clause_ptr *back_subsume();
struct clause_ptr *unit_conflict();
int propositional_clause();
int xx_resolvable();
int pos_clause();
int answer_lit();
int pos_eq_lit();
int neg_eq_lit();
int eq_lit();
int neg_clause();
int num_literals();
int num_answers();
int num_literals_including_answers();
int literal_number();
int unit_clause();
int horn_clause();
int equality_clause();
int symmetry_clause();
struct literal *ith_literal();
void append_cl();
void prepend_cl();
void insert_before_cl();
void insert_after_cl();
void rem_from_list();
void insert_clause();
int max_literal_weight();
int weight_cl();
void hide_clause();
void del_hidden_clauses();
struct clause *cl_copy();
int clause_ident();
void remove_var_syms();
void cl_insert_tab();
void cl_delete_tab();
struct clause *cl_find();
int lit_compare();
int ordered_sub_clause();
int sub_clause();
int sort_lits();
void all_cont_cl();
void zap_cl_list();
int is_eq();
void mark_literal();
int get_ancestors();
int renumber_vars();
int renum_vars_term();
void clear_var_names();
void cl_clear_vars();
int distinct_vars();
struct clause *find_first_cl();
struct clause *find_last_cl();
struct clause *find_random_cl();
struct clause *find_lightest_cl();
struct clause *find_lightest_geo_child();
struct clause *find_interactive_cl();
struct clause *find_given_clause();
struct clause *extract_given_clause();
int unit_del();
void back_unit_deletion();

/* options.c */

void init_options();
void print_options();
void p_options();
void auto_change_flag();
void dependent_flags();
void auto_change_parm();
void dependent_parms();
int change_flag();
int change_parm();
void check_options();

/* resolve.c */

int maximal_lit();
void hyper_res();
void neg_hyper_res();
void ur_res();
int one_unary_answer();
struct term *build_term();
void combine_answers();
struct clause *build_bin_res();
struct clause *apply_clause();
void bin_res();
struct clause *first_or_next_factor();
void all_factors();
int factor_simplify();

/* index.c */

void index_lits_all();
void un_index_lits_all();
void index_lits_clash();
void un_index_lits_clash();

/* paramod.c */

void para_from();
void para_into();

/* formula.c */

void print_formula();
void p_formula();
struct term *formula_to_term();
struct formula *term_to_formula();
struct formula *read_formula();
struct formula_ptr *read_formula_list();
void print_formula_list();
struct formula *copy_formula();
void zap_formula();
struct formula *negate_formula();
struct formula *nnf();
struct formula *skolemize();
struct formula *anti_skolemize();
void subst_free_formula();
void gen_sk_sym();
int skolem_symbol();
int contains_skolem_symbol();
int new_var_name();
int new_functor_name();
void unique_all();
struct formula *zap_quant();
void flatten_top();
struct formula *cnf();
struct formula *dnf();
void rename_syms_formula();
void subst_sn_term();
void subst_sn_formula();
int gen_subsume_prop();
struct formula *subsume_conj();
struct formula *subsume_disj();
int formula_ident();
void conflict_tautology();
void ts_and_fs();
struct list *clausify();
struct list *clausify_formula_list();
struct formula *negation_inward();
struct formula *expand_imp();
struct formula *iff_to_conj();
struct formula *iff_to_disj();
struct formula *nnf_cnf();
struct formula *nnf_dnf();
struct formula *nnf_skolemize();
struct formula *clausify_formed();
void rms_conflict_tautology();
struct formula *rms_subsume_conj();
struct formula *rms_subsume_disj();
int free_occurrence();
struct formula *rms_distribute_quants();
struct formula *rms_push_free();
struct formula *rms_quantifiers();
struct formula *rms();
struct formula *renumber_unique();
int gen_subsume_rec();
int gen_subsume();
int gen_conflict();
int gen_tautology();
struct formula *rms_cnf();
struct formula *rms_dnf();
struct formula *distribute_quantifier();

/* process.c */

void post_proc_all();
void infer_and_process();
int proc_gen();
void pre_process();

/* misc.c */

void init();
void abend();
void read_a_file();
void read_all_input();
void set_lex_vals();
void set_lrpo_status();
void set_special_unary();
void set_skolem();
void free_all_mem();
void output_stats();
void print_stats();
void print_stats_brief();
void p_stats();
void print_times();
void print_times_brief();
void p_times();
void append_lists();
struct term *copy_term();
int biggest_var();
int biggest_var_clause();
int ground_clause();
void zap_list();
int occurs_in();
int occurrences();
int sn_occur();
int is_atom();
int ident_nested_skolems();
int ground();
void cleanup();
int check_stop();
void report();
void control_memory();
void print_proof();
struct clause *check_for_proof();
int proper_list();
void move_clauses();
struct int_ptr *copy_int_ptr_list();
int int_list_length();
void automatic_1_settings();
void automatic_2_settings();
void log_for_x_show();
int same_structure();

/* lrpo.c */

int lrpo();
int lrpo_greater();
void order_equalities_lrpo();

/* linkur.c */

void linked_ur_res();
int process_linked_tags();

/* linkhyp.c */

void linked_hyper_res();

/* foreign.c */

long foo();
long user_test_long();
int user_test_bool();
char *user_test_string();
struct term *user_test_term();
void declare_user_functions();
int get_args_for_user_function();
struct term *long_to_term();
struct term *double_to_term();
struct term *bool_to_term();
struct term *string_to_term();
struct term *evaluate_user_function();

/* geometry.c */

int geo_rewrite();
void geometry_rule_unif();
int child_of_geometry();
void gl_demod();

/* hot.c */

void init_hot();
int heat_is_on();
void switch_to_hot_index();
void switch_to_ordinary_index();
void hot_index_clause();
void hot_dynamic();
void hot_mark_clash_cl();
void hot_inference();

/* nonport.c */

void non_portable_init();
void sig_handler();
char *username();
char *hostname();
void interact();
FILE *init_log_for_x_show();
int my_process_id();

/* dp_util.c */

int kludgey_e_subsume();
void check_for_bad_things();
int int_term();
int domain_element();
void dp_p_term();
int clause_to_pair();
void dp_transform();
void igcns_transform();

/* check.c */

struct gen_node *get_gen_node();
struct proof_object *get_proof_object();
struct proof_object_node *get_proof_object_node();
struct int_ptr *copy_ip_segment();
int trivial_subst();
void print_term_s();
void p_term_s();
void print_clause_s();
void p_clause_s();
void print_proof_object_node();
void p_proof_object_node();
void print_proof_object();
void p_proof_object();
struct clause *cl_copy_delete_literal();
int variant();
struct int_ptr *match_clauses();
struct clause *cl_append();
struct clause *identity_resolve();
void renumber_vars_subst();
int finish_translating();
int ipx();
int contains_answer_literal();
int contains_rule();
void build_proof_object();

/* hints.c */

void process_hint_attributes();
void print_hint_clause();
void p_hint_clause();
void print_hints_cl_list();
void p_hints_cl_list();
void adjust_weight_with_hints();
int back_subsume_hint();

/* attrib.c */

void init_attributes();
int get_attribute_index();
int attribute_type();
struct cl_attribute *get_attribute();
void set_attribute();
void delete_attributes();
struct cl_attribute *term_to_attributes();
void print_attributes();

/* case.c */

int splitting();
int max_split_depth();
int splitable_literal();
struct literal_data compare_literal_data();
int splitable_clause();
struct clause *compare_splitable_clauses();
void init_literal_data();
void p_literal_data();
void get_literal_data();
void print_case();
void p_case();
void print_case_n();
void p_case_n();
void p_assumption_depths();
struct int_ptr *current_case();
void add_subcase();
int case_depth();
struct clause *find_clause_to_split();
struct term *find_atom_to_split();
int prover_forks();
int split_clause();
int split_atom();
void possible_split();
void always_split();
void possible_given_split();
void assumps_to_parent();
void exit_with_possible_model();

/* prune.c */

int input_clauses_in_list();
struct clause *middle_clause();
void activity();
void p_activity();
void possible_prune();
